// myproject/firebase/config.ts
import { initializeApp } from 'firebase/app';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "YOUR_UNIQUE_API_KEY", 
  authDomain: "fastfood-8c039.firebaseapp.com",
  databaseURL: "https://fastfood-8c039.firebaseio.com", 
  projectId: "fastfood-8c039",
  storageBucket: "fastfood-8c039.appspot.com", 
  messagingSenderId: "1090712238805", 
  measurementId: "489890878" 
};


const app = initializeApp(firebaseConfig);
const storage = getStorage(app);

export { storage };
