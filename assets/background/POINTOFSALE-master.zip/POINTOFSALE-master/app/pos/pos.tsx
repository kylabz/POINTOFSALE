import React, { useEffect, useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, ScrollView,
  StyleSheet, Image, Dimensions, Alert, ImageBackground
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useRouter, useLocalSearchParams } from 'expo-router';

const screenWidth = Dimensions.get('window').width;
const DEFAULT_CATEGORIES = ['Pizza', 'Coffee', 'Sandwich', 'Softdrinks'];

export default function POSMenu() {
  const router = useRouter();
  const [products, setProducts] = useState<any[]>([]);
  const [cart, setCart] = useState<any[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const params = useLocalSearchParams();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const storedProducts = await AsyncStorage.getItem('products');
      const storedCart = await AsyncStorage.getItem('cart');
      const storedCategories = await AsyncStorage.getItem('categories');

      if (storedProducts) setProducts(JSON.parse(storedProducts));
      if (storedCart) setCart(JSON.parse(storedCart));
      if (storedCategories) {
        setCategories(JSON.parse(storedCategories));
      } else {
        setCategories(DEFAULT_CATEGORIES);
        await AsyncStorage.setItem('categories', JSON.stringify(DEFAULT_CATEGORIES));
      }
    } catch (error) {
      console.error("Failed loading data:", error);
    }
  };

  useEffect(() => {
    if (params?.newProduct) {
      const product = JSON.parse(params.newProduct as string);
      setProducts(prev => {
        const exists = prev.find(p => p.name === product.name);
        if (exists) return prev;
        const updated = [...prev, product];
        AsyncStorage.setItem('products', JSON.stringify(updated));
        return updated;
      });
    }
  }, [params]);

  const handleAddToCart = (product: any) => {
    if (product.quantity <= 0) {
      Alert.alert("Out of stock", "This product is currently unavailable.");
      return;
    }

    const updatedProducts = products.map(p =>
      p.name === product.name ? { ...p, quantity: p.quantity - 1 } : p
    );
    setProducts(updatedProducts);
    AsyncStorage.setItem('products', JSON.stringify(updatedProducts));

    const found = cart.find(item => item.name === product.name);
    if (found) {
      const updatedCart = cart.map(item =>
        item.name === product.name
          ? { ...item, quantity: item.quantity + 1 }
          : item
      );
      setCart(updatedCart);
      AsyncStorage.setItem('cart', JSON.stringify(updatedCart));
    } else {
      const newCart = [...cart, { ...product, quantity: 1 }];
      setCart(newCart);
      AsyncStorage.setItem('cart', JSON.stringify(newCart));
    }
  };

  const handleRemoveFromCart = (index: number) => {
    const itemToRemove = cart[index];
    const updatedProducts = products.map(p =>
      p.name === itemToRemove.name
        ? { ...p, quantity: p.quantity + itemToRemove.quantity }
        : p
    );
    setProducts(updatedProducts);
    AsyncStorage.setItem('products', JSON.stringify(updatedProducts));

    const updatedCart = cart.filter((_, i) => i !== index);
    setCart(updatedCart);
    AsyncStorage.setItem('cart', JSON.stringify(updatedCart));
  };

  const handleDeleteProduct = (productName: string) => {
    Alert.alert(
      "Confirm Deletion",
      `Are you sure you want to delete "${productName}"?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete", style: "destructive", onPress: async () => {
            try {
              const updatedProducts = products.filter(product => product.name !== productName);
              await AsyncStorage.setItem('products', JSON.stringify(updatedProducts));
              setProducts(updatedProducts);

              const updatedCart = cart.filter(item => item.name !== productName);
              await AsyncStorage.setItem('cart', JSON.stringify(updatedCart));
              setCart(updatedCart);

              Alert.alert("Deleted", `"${productName}" has been removed.`);
            } catch (error) {
              Alert.alert("Error", "Failed to delete product.");
              console.error(error);
            }
          }
        }
      ]
    );
  };

  const handleGenerateReceipt = async () => {
    if (cart.length === 0) {
      Alert.alert("No Purchase", "Your cart is empty.");
      return;
    }
    await AsyncStorage.setItem('receiptCart', JSON.stringify(cart));
    setCart([]);
    AsyncStorage.setItem('cart', JSON.stringify([]));
    router.push('/pos/ReceiptScreen');
  };

  const filteredProducts = products.filter(p =>
    (!selectedCategory || p.category === selectedCategory) &&
    p.name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <ImageBackground
      source={require('../../assets/background/fastfood.png')}
      style={styles.backgroundImage}
      resizeMode="cover"
    >
      <View style={styles.overlay}>
        <Text style={styles.header}>FASTFOOD MENU</Text>

        <TextInput
          placeholder="Search product"
          placeholderTextColor="#ccc"
          style={styles.searchBar}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />

        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryScroll}>
          {categories.map(cat => (
            <TouchableOpacity
              key={cat}
              style={[styles.categoryButton, selectedCategory === cat && styles.selectedCategory]}
              onPress={() => setSelectedCategory(cat)}
            >
              <Text style={[styles.categoryText, selectedCategory === cat && { color: '#fff' }]}>{cat}</Text>
            </TouchableOpacity>
          ))}
          <TouchableOpacity
            style={[styles.categoryButton, selectedCategory === null && styles.selectedCategory]}
            onPress={() => setSelectedCategory(null)}
          >
            <Text style={[styles.categoryText, selectedCategory === null && { color: '#fff' }]}>All</Text>
          </TouchableOpacity>
        </ScrollView>

        <ScrollView contentContainerStyle={styles.grid}>
          {filteredProducts.map((product, index) => (
            <View key={index} style={[styles.card, product.quantity <= 0 && styles.cardDisabled]}>
              {product.image ? (
                <Image
                  source={{ uri: product.image }}
                  style={styles.image}
                  resizeMode="contain"
                />
              ) : (
                <View style={[styles.image, { justifyContent: 'center', alignItems: 'center', backgroundColor: '#555' }]}>
                  <Text style={{ color: '#ccc' }}>No Image</Text>
                </View>
              )}
              <Text style={styles.productName}>{product.name}</Text>
              <Text style={styles.productPrice}>₱{product.price}</Text>
              <Text style={styles.productStock}>Stock: {product.quantity}</Text>
              <Text style={styles.productCategory}>{product.category}</Text>

              <TouchableOpacity
                style={styles.deleteButton}
                onPress={() => handleDeleteProduct(product.name)}
              >
                <Text style={styles.deleteText}>Delete</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.addToCartButton}
                onPress={() => handleAddToCart(product)}
                disabled={product.quantity <= 0}
              >
                <Text style={styles.addToCartText}>Add to Cart</Text>
              </TouchableOpacity>
            </View>
          ))}
        </ScrollView>

        <View style={styles.cartContainer}>
          <Text style={styles.cartTitle}>Cart</Text>
          {cart.length === 0 ? (
            <Text style={styles.emptyCart}>No items added yet</Text>
          ) : (
            cart.map((item, i) => (
              <View key={i} style={styles.cartRow}>
                <Text style={styles.cartItem}>
                  {item.name} - ₱{item.price} x {item.quantity}
                </Text>
                <TouchableOpacity onPress={() => handleRemoveFromCart(i)}>
                  <Text style={styles.remove}>Remove</Text>
                </TouchableOpacity>
              </View>
            ))
          )}
        </View>

        <View style={styles.buttonRow}>
          <TouchableOpacity style={styles.addButton} onPress={() => router.push('/pos/AddProduct')}>
            <Text style={styles.btnText}>+ Product</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.receiptButton} onPress={handleGenerateReceipt}>
            <Text style={styles.btnText}>Receipt</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.settingsButton} onPress={() => router.push('/pos/Settings')}>
            <Text style={styles.btnText}>Settings</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.chatButton} onPress={() => router.push('/pos/ChatSupport')}>
            <Text style={styles.btnText}>Chat</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  backgroundImage: { flex: 1, width: '100%', height: '100%' },
  overlay: { flex: 1, padding: 10 },
  header: { fontSize: 28, fontWeight: 'bold', textAlign: 'center', marginBottom: 10, color: '#fff' },
  searchBar: {
    backgroundColor: '#222', color: '#fff',
    borderRadius: 10, padding: 10,
    marginBottom: 10,
  },
  categoryScroll: { maxHeight: 50, marginBottom: 10 },
  categoryButton: {
    backgroundColor: '#333',
    marginRight: 10,
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
  },
  selectedCategory: {
    backgroundColor: '#0080ff',
  },
  categoryText: {
    color: '#aaa',
    fontWeight: 'bold',
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  card: {
    backgroundColor: '#222',
    margin: 5,
    width: screenWidth / 2 - 20,
    borderRadius: 20,
    padding: 10,
    alignItems: 'center',
  },
  cardDisabled: {
    opacity: 0.5,
  },
  image: {
    width: '100%',
    height: 100,
    borderRadius: 15,
    marginBottom: 5,
  },
  productName: { color: '#fff', fontWeight: 'bold', fontSize: 16, marginBottom: 2, textAlign: 'center' },
  productPrice: { color: '#0f0', marginBottom: 2 },
  productStock: { color: '#ccc', marginBottom: 2 },
  productCategory: { color: '#888', marginBottom: 10, fontSize: 12 },
  deleteButton: {
    backgroundColor: '#ff4444',
    paddingVertical: 5,
    paddingHorizontal: 15,
    borderRadius: 15,
    marginBottom: 8,
  },
  deleteText: { color: '#fff', fontWeight: 'bold' },
  addToCartButton: {
    backgroundColor: '#00aa00',
    paddingVertical: 8,
    paddingHorizontal: 20,
    borderRadius: 15,
  },
  addToCartText: { color: '#fff', fontWeight: 'bold' },
  cartContainer: {
    backgroundColor: '#111',
    padding: 10,
    marginTop: 10,
    borderRadius: 10,
    maxHeight: 150,
  },
  cartTitle: { color: '#fff', fontWeight: 'bold', fontSize: 18, marginBottom: 5 },
  emptyCart: { color: '#999', fontStyle: 'italic' },
  cartRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 5,
  },
  cartItem: { color: '#fff' },
  remove: { color: '#f44', fontWeight: 'bold' },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 10,
    flexWrap: 'wrap',
  },
  addButton: {
    backgroundColor: '#0080ff',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 15,
    marginVertical: 5,
  },
  receiptButton: {
    backgroundColor: '#ffaa00',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 15,
    marginVertical: 5,
  },
  settingsButton: {
    backgroundColor: '#666',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 15,
    marginVertical: 5,
  },
  chatButton: {
    backgroundColor: '#9b59b6',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 15,
    marginVertical: 5,
  },
  btnText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});
