import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ReceiptScreen = () => {
  const [receipts, setReceipts] = useState([]);

  useEffect(() => {
    // Fetch receipts from backend
    axios.get('http://localhost:5000/api/receipts')
      .then((response) => {
        // Ensure response.data is an array before setting it to state
        if (Array.isArray(response.data)) {
          setReceipts(response.data);
        } else {
          console.error('Expected an array of receipts, but got:', response.data);
          setReceipts([]); // Reset to empty array if invalid data
        }
      })
      .catch((err) => {
        console.error('Error fetching receipts:', err);
      });
  }, []);

  return (
    <div>
      <h2>Receipts</h2>
      {/* Check if receipts is an array before mapping */}
      {Array.isArray(receipts) && receipts.length > 0 ? (
        receipts.map((receipt) => (
          <div key={receipt._id}>
            <h3>{receipt.product}</h3>
            <p>Quantity: {receipt.quantity}</p>
            <p>Total Price: {receipt.totalPrice}</p>
          </div>
        ))
      ) : (
        <p>No receipts available</p>
      )}
    </div>
  );
};

export default ReceiptScreen;
